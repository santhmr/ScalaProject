package com.pc.sparksql

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions._

object ORCFileProcessing {
  
  def main(args:Array[String]):Unit ={
    
    val spark = SparkSession.builder()
                .appName("ORCFileProcessing")
                .master("local[*]")
                .getOrCreate()
                
                
   val df = spark.read.orc("E:/Scala_Durga/ScalaTraining/output/cust_orc")
    df.printSchema()
    df.show()
    
    df.select("name","price").show
    
    val newDF = df.withColumn("county", lit("INDIA"))
    newDF.printSchema()
    newDF.show()
    
    
    //cust_id
    val finalDF = newDF.drop("cust_id")
    finalDF.printSchema
    finalDF.show
    
    
    
  }
  
}