package com.pc.sparksql

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.broadcast
import org.apache.spark.sql.functions._

object BroadCastJoin {
  
  def main(args:Array[String]):Unit ={
    
     //Entry point for Spark SQL
    val spark = SparkSession.builder
                .appName("BroadCastJoin")
                .master("local[*]")
                .getOrCreate()
                
    spark.sparkContext.setLogLevel("OFF") 

    import spark.implicits._ 
    //Fact Table or big table    DataFrameReader spark.read --connects to data sources      
    val transDF = spark.read
      .option("header", "true")
      .option("inferSchema","true")
      .csv("E:/Scala_Durga/Spark_Project/transaction_data.csv")
      
   
  transDF.printSchema()
  transDF.show()
  
  //Dimension or small table
   val custDF = spark.read
      .option("header", "true")
      .option("inferSchema","true")
      .csv("E:/Scala_Durga/Spark_Project/customer_data.csv")
      
  custDF.printSchema()
  custDF.show()
 
 
  //1. inner or equi join -- default
  //2. left outer join
  //3. right outer join 
  //4. full outer join
  
  //DSL 
  val innerJoinDF = transDF.join(broadcast(custDF),transDF("cust_id")===custDF("cust_id"),"inner")
  innerJoinDF.printSchema
  innerJoinDF.show
  
  //DataFrameWriter df.write which writes to data sources 
  //Columnar 1,2,3,4,5,A,B,C,D,100.0,200.00..
  //1. Parquet -> GZIP, Snappy an bzip2 + schema
  //2. ORC  -> Optimized Record Columnar format ACID properties 
  //3. Avro -> Supports external language + json 
  
  
  innerJoinDF.cache() //MEMORY AND DISK 
  
  //tras_id|cust_id|name|product|price
  
  val finalDF = innerJoinDF.select(
      $"tras_id",
      transDF("cust_id"),
      $"name",
      $"product",
      $"price")
  
  finalDF.write.parquet("E:/Scala_Durga/ScalaTraining/output/cust_pq")
  finalDF.write.orc("E:/Scala_Durga/ScalaTraining/output/cust_orc")
  //finalDF.write.format("avro").save("E:/Scala_Durga/ScalaTraining/output/cust_avro")

  //innerJoinDF.write.format("parquet").save("")
  

  }
  
}