package com.pc.sparksql

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql._

object CustomerDriver {
  
   def main(args:Array[String]):Unit = {
    
    //Entry point for Spark SQL
    val spark = SparkSession.builder
                .appName("CustomerDriver")
                .master("local[*]")
                .getOrCreate()
                
     spark.sparkContext.setLogLevel("OFF")           
     
    //spark.read = DataFrameReader  -- DataSources CSV,TSV and DB etc
    //DataFrame -- Untype Dataset[Row] schema Row 
    //Dataset[T] -- Type of an object  
     
    val custDF:DataFrame = spark.read
    .option("header","true")
    .option("inferSchema","true")
    .csv("E:\\Scala_Durga\\Spark_Project\\customer.csv")
    
    custDF.printSchema
    custDF.show
    
    //1. DSL    
    //name,price
    val selectCustDF = custDF.select("name","price")
    selectCustDF.printSchema
    selectCustDF.show
    
    //2. SQL
     custDF.createOrReplaceTempView("customer_table")
     custDF.createOrReplaceGlobalTempView("customer_table_global")
     
     val custDF1 = spark.sql("SELECT * FROM customer_table")
     custDF1.printSchema()
     custDF1.show()
     
     spark.sql("SELECT name,price FROM customer_table").show()
     spark.sql("SELECT name,price FROM customer_table ORDER BY price DESC").show()
     spark.sql("SELECT name,max(price) FROM customer_table GROUP BY name").show()
     
    //custDF1.write -- DataFrameWriter write to data into data sources (CSV, TSV and JDBC etc) 
    custDF1.write.mode(SaveMode.Append).save("E:/Scala_Durga/ScalaTraining/output/df_out")  
     
    
     
    
                
   }
  
}