package com.pc.sparksql

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.udf

object UDFTest {
  //explict func 
  def myUpper(input:String):String = input.toUpperCase
  
  def main(args:Array[String]):Unit = {
    
    //Entry point for Spark SQL
    val spark = SparkSession.builder
                .appName("CustomerDriver")
                .master("local[*]")
                .getOrCreate()
     spark.sparkContext.setLogLevel("OFF")
     
     import spark.implicits._
     
     //Anonymous Func
     //val myUpper1:(String => String) =  (input:String) => input.toUpperCase()
     val upper: (String => String) = _.toUpperCase()
    
     println(upper("abc"))
     val myUpperUDF = udf[String,String](myUpper _ )
     
     val df =spark.read.json("E:/Scala_Durga/Spark_Project/customer.json")
     df.printSchema
     df.show
     
     //DSL
     //cust_id, name, upper_case
     val newDF = df.withColumn("uppper_case", myUpperUDF($"name"))
     newDF.printSchema
     newDF.show
     
     df.select(myUpperUDF($"name")).show()
     
     
     //2 . SQL
     spark.udf.register("myUpperCase", upper)
     spark.sql("SELECT myUpperCase('sparksql')").show 
     
     df.createOrReplaceTempView("customer_tmp_table")
     
     
     spark.sql("SELECT myUpperCase(cust_id), myUpperCase(name) FROM customer_tmp_table").show()
    
     
     
     
     
  }
  
}