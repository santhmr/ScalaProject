package com.pc.sparksql

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.types._

object CreateDFWithoutSchema {

  def main(args: Array[String]): Unit = {

    //Entry point for Spark SQL
    val spark = SparkSession.builder
      .appName("CreateDFWithoutSchema")
      .master("local[*]")
      .getOrCreate()

    spark.sparkContext.setLogLevel("OFF")

    import spark.implicits._

    val schema = StructType(
      Array(
        StructField("tid", IntegerType, true),
        StructField("cid", IntegerType, true),
        StructField("product", StringType, true),
        StructField("price", DoubleType, true)))

    val filePath = "E:\\Scala_Durga\\Spark_Project\\transaction_data2.csv"

    val df = spark.read
      .option("header", "false")
      .option("inferSchema", "false")
      .option("sep", ",")
      .schema(schema)
      .csv(filePath)
      
      
    df.printSchema
    df.show
    
   df.createOrReplaceTempView("trans_table")
   
   spark.sql("SELECT product, price FROM trans_table").show()

  }

}
