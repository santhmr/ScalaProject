package com.pc.sparksql

import org.apache.spark.sql.SparkSession
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.Dataset

case class Transaction(tid: Int, cid: Int, product: String, price: Double)

object ProcessTransactionsDS {
  
  //f: (String => Transaction)
  //"111,1,Laptop,50000" => Transaction(111,1,Laptop,50000)
  def parseLine(input:String):Transaction = {
    
    val cols:Array[String] = input.split(",")
    
    val tid= cols(0).toInt
    val cid = cols(1).toInt
    val product = cols(2)
    val price = cols(3).toDouble
    Transaction(tid,cid,product,price)
  }
  

  def main(args: Array[String]): Unit = {

    //Entry point for Spark SQL
    val spark = SparkSession.builder
      .appName("ProcessTransactionsDS")
      .master("local[*]")
      .getOrCreate()

    spark.sparkContext.setLogLevel("OFF")
    
    

    val inputRDD: RDD[String] = spark.sparkContext.textFile("E:\\Scala_Durga\\Spark_Project\\transaction_data2.csv")
    inputRDD.foreach(println)
    /*
		 "111,1,Laptop,50000"
		 "116,3,Laptop,40000"
		 "112,2,TV,60000"
		 */
    
    //RDD[String] to RDD[Transaction]
    val transactionRDD : RDD[Transaction] = inputRDD.map(s => parseLine(s) )
    transactionRDD.foreach(println)
    
    import spark.implicits._
    
    val transDS:Dataset[Transaction] = transactionRDD.toDS
    transDS.printSchema()
    transDS.show()
    
    transDS.createOrReplaceTempView("transaction_table")
    
    spark.sql("SELECT * FROM transaction_table").show()
    
    

  }

}