package com.pc.sparksql

import org.apache.spark.sql.SparkSession
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.types.DoubleType


object ProcessTransactionsDS2 {
  
  //String => Row
  //"111,1,Laptop,50000" => Row(111,1,Laptop,50000)
  def parseLine(input:String):Row = {
    
    val cols:Array[String] = input.split(",")
    
    val tid:String= cols(0)
    val cid:String = cols(1)
    val product:String = cols(2)
    val price:String = cols(3)
    Row(tid,cid,product,price)
  }
  

  def main(args: Array[String]): Unit = {

    //Entry point for Spark SQL
    val spark = SparkSession.builder
      .appName("ProcessTransactionsDS1")
      .master("local[*]")
      .getOrCreate()

    spark.sparkContext.setLogLevel("OFF")
    
    import spark.implicits._
    
    

    val inputRDD: RDD[String] = spark.sparkContext.textFile("E:\\Scala_Durga\\Spark_Project\\transaction_data2.csv")
    inputRDD.foreach(println)
    /*
		 "111,1,Laptop,50000"
		 "116,3,Laptop,40000"
		 "112,2,TV,60000"
		 */
    
    //RDD[String] to RDD[Transaction]
    val transactionRDD : RDD[Row] = inputRDD.map(s => parseLine(s) )
    transactionRDD.foreach(println)
    
    import spark.implicits._
    
    val header = "tid|cid|product|price"
    
  val df_schema = StructType(
    header.split('|').map(fieldName => StructField(fieldName, StringType, true)))
    
    
  val schema = StructType( 
       Array(
              StructField("tid", IntegerType, true),
              StructField("cid", IntegerType, true),
              StructField("product", StringType, true),
              StructField("price", DoubleType, true)
           )
      )
    
    spark.createDataFrame(transactionRDD,df_schema).show
    
   
    

  }

}