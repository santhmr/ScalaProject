package com.pc.sparksql

import org.apache.spark.sql.SparkSession

object JSONFileProcess {
  
  def main(args:Array[String]):Unit ={
    
     //Entry point for Spark SQL
    val spark = SparkSession.builder
                .appName("JSONFileProcess")
                .master("local[*]")
                .getOrCreate()
     spark.sparkContext.setLogLevel("OFF") 
     
    //DataFrameReader 
     val df =spark.read.json("E:/Scala_Durga/Spark_Project/customer.json")
     df.printSchema
     df.show
     
  }
  
}