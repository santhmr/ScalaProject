package com.pc.sparksql

import org.apache.spark.sql.SparkSession

object JoinCustomerDF {
  
  def main(args:Array[String]):Unit ={
    
     //Entry point for Spark SQL
    val spark = SparkSession.builder
                .appName("JoinCustomerDF")
                .master("local[*]")
                .getOrCreate()
                
    spark.sparkContext.setLogLevel("OFF") 

    import spark.implicits._ 
                
    val transDF = spark.read
      .option("header", "true")
      .option("inferSchema","true")
      .csv("E:/Scala_Durga/Spark_Project/transaction_data.csv")
      
   
  transDF.printSchema()
  transDF.show()
  
  
   val custDF = spark.read
      .option("header", "true")
      .option("inferSchema","true")
      .csv("E:/Scala_Durga/Spark_Project/customer_data.csv")
      
  custDF.printSchema()
  custDF.show()
 
 
  //1. inner or equi join -- default
  //2. left outer join
  //3. right outer join 
  //4. full outer join
  
  //DSL 
  val innerJoinDF = transDF.join(custDF,transDF("cust_id")===custDF("cust_id"),"inner")
  innerJoinDF.printSchema
  innerJoinDF.show
  
  innerJoinDF.select("price").show()  //String name
  innerJoinDF.select($"price").show() //Column  --Recommend
  innerJoinDF.select(innerJoinDF("price")).show() //Column
  innerJoinDF.select(innerJoinDF.col("price")).show() //Column
  
  
  val leftJoinDF = transDF.join(custDF,transDF("cust_id") ===custDF("cust_id"),"left_outer")
  leftJoinDF.printSchema
  leftJoinDF.show
  
  
   val rightJoinDF = transDF.join(custDF,transDF("cust_id")===custDF("cust_id"),"right_outer")
   rightJoinDF.printSchema
   rightJoinDF.show
   
   
   val fullJoinDF = transDF.join(custDF,transDF("cust_id")===custDF("cust_id"),"full_outer")
   fullJoinDF.printSchema
   fullJoinDF.show
   
   
  val finalDF= fullJoinDF.select(
       $"tras_id",
       $"product",
       $"price",
       $"name"
       )
       
   finalDF.printSchema()
   finalDF.show()
   
   
   
   finalDF.filter($"price" >5000).show //dsl 
   finalDF.where($"price" >5000).show //sql 
   

   //DataFrameWriter df.write 
   finalDF.repartition(10).write.csv("E:/Scala_Durga/ScalaTraining/output/cust_final_output1")
   finalDF.coalesce(1).write.csv("E:/Scala_Durga/ScalaTraining/output/cust_final_output22")
   finalDF.repartition(1).write.partitionBy("product").save("E:/Scala_Durga/ScalaTraining/output/cust_final_output4")
 
      
                
  }
  
}