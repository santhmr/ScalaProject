package com.pc.sparksql

import org.apache.spark.sql.SparkSession

object ParquetFileProcess {
  
  def main(args:Array[String]):Unit ={
    
    val spark = SparkSession.builder()
                .appName("ParquetFileProcess")
                .master("local[*]")
                .getOrCreate()
                
                
   val df = spark.read.parquet("E:/Scala_Durga/ScalaTraining/output/cust_pq")
    
    //spark.read.orc("")
    
    df.printSchema()
    df.show()
    
    df.select("name","price").show
    
  }
  
}