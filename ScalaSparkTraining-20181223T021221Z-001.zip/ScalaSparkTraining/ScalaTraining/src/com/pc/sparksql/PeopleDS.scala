package com.pc.sparksql

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Dataset

//T - People
case class People(ID:Int, name:String)

object PeopleDS
{
  
   def main(args:Array[String]):Unit = {
    
    //Entry point for Spark SQL
    val spark = SparkSession.builder
                .appName("PeopleDS")
                .master("local[*]")
                .getOrCreate()
                
     spark.sparkContext.setLogLevel("OFF")  
    
     //Encoder and Encoders  
    import spark.implicits._
   
   //Scala collections -- Seq, List, Set and Map 
   val peoples:Dataset[People] =  Seq(
         People(1,"Durga"),
         People(2,"Raj"),
         People(3,"Prakash"),
         People(4,"Ram"),
         People(5,"Durga"),
         People(6,"Raj"),
         People(7,"Prakash"),
         People(8,"Ram"),
         People(9,"Durga"),
         People(10,"Raj"),
         People(11,"Prakash"),
         People(12,"Ram"),
         People(13,"Santosh"),
         People(14,"Manoj"),
         People(15,"Krishna")
     ).toDS()
     
     
     peoples.printSchema
     peoples.show
     
     //1. SQL
     //peoples.createOrReplaceTempView("people_table")
     //spark.sql("SELECT * FROM people_table WHERE ID<=10").show
     
     //2. Function(RDD)
     //peoples.filter((p:People) => p.ID <=10).show
     
     
     //3. Expression based
      println("filter")
      peoples.filter($"ID" <=10).show
      println("where")
      peoples.where($"ID" <=10).show
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
   }
  
}