package com.pc.streaming

import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.streaming.dstream.DStream

/**
  * Created by hduser on 1/27/17.
  */
object StatefulWordCount
{


  def updateFn(currentValues:Seq[Int],runningCount:Option[Int]) : Option[Int] =
  {

    val newState =  currentValues.sum + runningCount.getOrElse(0)

    Some(newState) //value or None
  }

  def main(args: Array[String]): Unit =
  {

    //1. Spark Conf
    val conf = new SparkConf().setAppName("Stateful Word Count Demo").setMaster("local[2]")

    //2. Spark Streaming Context

    val ssc = new StreamingContext(conf,Seconds(5))  //batch interval
    
    ssc.checkpoint("/home/hduser/Projects/SparkProject/src/main/resources/checkpointdir")


    val  dstreamLines:DStream[String] = ssc.socketTextStream("localhost",50050)

    //During each 5 seconds, need to find word count
    //Input Apache Spark Streaming
    val words:DStream[String] = dstreamLines.flatMap(line => line.split(" "))

    //word => (Word,1)

    val wordsPair:DStream[(String,Int)] = words.map(word => (word,1))

    //Shuffle (Apache {1,1,1,1,1,1}
    //val countByKey = wordsPair.reduceByKey((a,b) => a+b)



    //state
    val totalCountByKey = wordsPair.updateStateByKey(updateFn _)

    totalCountByKey.print()



    ssc.start()
    ssc.awaitTermination()

  }

}
