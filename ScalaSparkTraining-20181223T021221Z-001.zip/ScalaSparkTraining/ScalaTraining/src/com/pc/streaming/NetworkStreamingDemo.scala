package com.pc.streaming

import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Seconds, StreamingContext}


/**
  * Created by hduser on 1/24/17.
  */
object NetworkStreamingDemo
{

  def main(args: Array[String]): Unit =
  {

    //1. Spark Conf
    val conf = new SparkConf().setAppName("NetworkStreamingDemo").setMaster("local[2]")

    //2. Spark Streaming Context
    val ssc = new StreamingContext(conf,Seconds(5))  //batch interval

   //nc -lk 9999
   val  dstream:DStream[String] = ssc.socketTextStream("localhost",9999)

    dstream.count().print()
    dstream.print()


    ssc.start()
    ssc.awaitTermination()

  }
}
