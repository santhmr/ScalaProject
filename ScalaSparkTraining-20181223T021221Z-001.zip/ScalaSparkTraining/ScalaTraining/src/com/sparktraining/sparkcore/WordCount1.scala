package com.sparktraining.sparkcore

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object WordCount1 {
  
  def main(args:Array[String]):Unit = {
    
    //Entry point spark sql
    val spark = SparkSession
                .builder
                .appName("WordCount1")
                .master("local[*]")
                .getOrCreate()
                
   spark.sparkContext.setLogLevel("ERROR")             
                
   val baseRDD:RDD[String] = spark.sparkContext.textFile("E:/Scala_Durga/ScalaTraining/input")
   //baseRDD.flatMap(_.split(" ")).map((_,1)).reduceByKey(_+_).foreach(println) 
   baseRDD.flatMap(_.split(" ")).map((_,1)).countByKey().foreach(println) 
   
  }
  
}