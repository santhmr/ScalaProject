package com.sparktraining.sparkcore

import org.apache.spark.sql.SparkSession
import org.apache.spark.rdd.RDD

object WordCount {
  
  def main(args:Array[String]):Unit = {
    
    //Entry point spark sql
    val spark = SparkSession
                .builder
                .appName("WordCount")
                .master("local[*]")
                .getOrCreate()
                
   spark.sparkContext.setLogLevel("ERROR")             
                
   val baseRDD:RDD[String] = spark.sparkContext.textFile("E:/Scala_Durga/ScalaTraining/input")
   
   //line of string into words
   val wordsRDD:RDD[String] = baseRDD.flatMap((line:String) => line.split(" "))
   
   //word => (word,1) 
   val wordPairRDD:RDD[(String,Int)] = wordsRDD.map((word:String) => (word,1))
   
   //groupByKey (Spark, (1,1,1,1)) (k, v) (String, List)
   val groupedRDD = wordPairRDD.groupByKey()
   
   val wordCount = groupedRDD.map( t => (t._1, t._2.size))
   //Trigger an action
   wordCount foreach println
   //Trigger an action
   println(wordCount.count())
   
   
  }
  
  
}