package com.sparktraining.structurestreaming

import org.apache.spark.sql.SparkSession

object CSVStructureStreaming {
  
  def main(args:Array[String]):Unit = {
    
     //Entry point spark sql
    val spark = SparkSession
                .builder
                .appName("WordCount")
                .master("local[*]")
                .getOrCreate()
                
   spark.sparkContext.setLogLevel("ERROR")    
   
   val csvDF = spark
  .readStream
  //.option("sep", ";")
  //.schema(userSchema)      // Specify schema of the csv files
  .option("header", "true")
  .option("inferSchema", "true")
  .csv("E:/Scala_Durga/ScalaTraining/input_dir")    // Equivalent to format("csv").load("/path/to/directory")
    
  val query = csvDF.writeStream
  .outputMode("complete")
  .format("console")
  .start()

query.awaitTermination()
  
  }
}