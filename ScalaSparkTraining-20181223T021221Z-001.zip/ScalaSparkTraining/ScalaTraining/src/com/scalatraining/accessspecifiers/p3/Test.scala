package com.scalatraining.accessspecifiers.p3

import com.scalatraining.accessspecifiers.p1.{A,B,C}


import com.scalatraining.accessspecifiers.p2.{D,E}
object Test {
  
  def main(args:Array[String]):Unit ={
    
    val a:A = new A
    a.display()
    
    val b:B = new B
    b.display
    
    val c:C = new C
    c.display()
    
    //p2
    val d:D = new D
    d.display
    
    val e:E = new E
    e.display
    
    
    
    
  }
}