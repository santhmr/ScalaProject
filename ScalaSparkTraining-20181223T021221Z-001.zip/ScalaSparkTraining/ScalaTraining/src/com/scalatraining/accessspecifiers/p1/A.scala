package com.scalatraining.accessspecifiers.p1

class A {
  private val i:Int = 10
  protected val j:Int = 20
            val k:Int = 30
   
 
  def display(){
    println("A display...")
    println(s"i=$i j=$j k=$k")
    
    val a = new A
    println(s"i=${a.i} j=${a.j} k=${a.k}")
  }
  
}

class B extends A{
  
 override def display(){
    println("B display...")
    println(s"j=$j k=$k")
    
    val a = new A
    println(s"k=${a.k}") // Not access i,j
  }
  
}


class C {
  
  def display(){
    println("C display...")
    
    val a = new A
    println(s"i=k=${a.k}") // Not access i , Not projected variable sub
  }
  
  
}