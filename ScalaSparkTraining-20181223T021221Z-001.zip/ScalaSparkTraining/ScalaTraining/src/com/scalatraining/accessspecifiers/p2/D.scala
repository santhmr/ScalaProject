package com.scalatraining.accessspecifiers.p2

import com.scalatraining.accessspecifiers.p1.A

class D extends A{

  override def display(){
    println("D display...")
    println(s"j=$j k=$k") 
    
    val a = new A
    println(s"k=${a.k}") // Not access i,j
  }
  
}

class E {

   def display(){
    println("E display...")
 
    val a = new A
    println(s"k=${a.k}") // Not access i,j
  }
  
}