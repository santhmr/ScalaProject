package com.scalatraining.arrays

/**
  * Created by admin1 on 2/5/2017.
  */
object ArrayDemo
{

  def main(args:Array[String]):Unit = {

    val arr:Array[Int] = Array(1,2,3,4,5)

    //arr(0)
    println(arr(0)) // Java arr[0] 
    println(arr(1))
    
    arr(4) = 50
    
    println("For")
    for( i <- arr)
      {
        println(i)
      }

    println("foreach")
    //arr.foreach( e => println(e))
    //arr.foreach(println)
    arr foreach println 




  }

}
