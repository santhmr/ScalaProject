package com.scalatraining

import scala.io.StdIn

object FactRec {
 
  //5 
  //5*4*3*2*1

  def fact(n:Int):Int = {
    if(n==0)
      1
    else
      n*fact(n-1) // Stack
                  // Stack
                  // Stack 
  }
  
  def main(args:Array[String]):Unit ={
    
    val inputValue = StdIn.readInt()
    val factResult = fact(inputValue) // Stack 
    println(s"Factorial of $inputValue = $factResult")
  
}
  
}