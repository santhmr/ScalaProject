package com.scalatraining.functions

object AddDemo {
 
  implicit val i=10
  
  
  def add(i:Int, j:Int ):Int = {
      return i+j
  }
  
  def main(args:Array[String]):Unit ={
    
    val output = AddDemo.add(10,20)
    println(output)
    
    val output1 = add(100,200)
    println(output1)
    
    //println(add(20))
    
    
    
  }
}