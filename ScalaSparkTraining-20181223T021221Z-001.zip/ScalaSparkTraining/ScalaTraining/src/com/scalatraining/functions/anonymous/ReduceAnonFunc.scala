package com.scalatraining.functions.anonymous

object ReduceAnonFunc {
  
  def add(a:Int,b:Int) = a+b 
  
  def main(args:Array[String]):Unit ={
    
    val nums = (1 to 10).toList
    
    // class Function0
    // class Function1
    // class  Function2
    val i:Int = 10
    val add1:(Int,Int) => (Int) =  (a:Int,b:Int) => a+b
    
    println(add(10,20))
    println(add1(100,200))
    
    
    //val sum = nums.reduce((a:Int,b:Int) => a+b) 
    val sum = nums.reduce(_+_)
    println(sum)
    
    
    
  }
}