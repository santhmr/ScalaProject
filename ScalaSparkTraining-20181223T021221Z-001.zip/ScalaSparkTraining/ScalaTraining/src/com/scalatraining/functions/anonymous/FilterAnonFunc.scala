package com.scalatraining.functions.anonymous

object FilterAnonFunc {
  
  def main(args:Array[String]):Unit ={
   
    val nums = (1 to 10).toList
    
    //(Int) => Boolean 
    
    
    //val evenList = nums.filter((n:Int) => n%2 == 0 ) //inline function or anonymous function or lambda
    //val evenList = nums.filter(n => n%2 == 0)
    val evenList = nums.filter(_%2 == 0)
    
    
    //2,4,6,8,10
    //(n:Int) => println(n)
    //(Int) => Unit
    //evenList.foreach((n:Int) => println(n))
    //evenList.foreach(n => println(n))
    evenList.foreach(println)
    
    
    nums.filter(_%2 == 0).foreach(println)
    
    val nums1:List[Int] = List(1,2,3,4,5,6,7,8,9,10)
    
    val mapList:List[Boolean]  = nums1.map((n:Int) => n%2 == 0 )
    mapList.foreach(println)
    
  }
}