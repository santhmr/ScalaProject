package com.scalatraining.functions.higherorder

object WordCount {
  
  def main(args:Array[String]):Unit ={
    
     val strList = List(
           "Scala is a functional programming",
           "Scala is an object oriented programming",
           "Scala is run jvm",
           "Scala is a scripting language"
        )
        
   //1. String => flatten words
   val words:List[String] = strList.flatMap((s:String) => s.split(" ") )     
   words.foreach(println)
   
   //2. Word => (word,1) tuple (1,"kumar",1000.00) _1,_2,_3
   val wordsPair = words.map((word:String) => (word,1))
   wordsPair.foreach(println)
   
   //3. (Word,1) => GroupBy()
   
   val groupByWord = wordsPair.groupBy(t => t._1)
   groupByWord.foreach(println)
  
   //(Scala,List((Scala,1), (Scala,1), (Scala,1), (Scala,1))) => (Scala, _2.size)
   val wordCount = groupByWord.map(t => (t._1, t._2.size))
   //WordCount
   // Scala 4
   
   wordCount.foreach(println)
        
        
        
  }
  
}