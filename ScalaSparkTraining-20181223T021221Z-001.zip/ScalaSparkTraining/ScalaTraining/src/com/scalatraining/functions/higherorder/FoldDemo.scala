package com.scalatraining.functions.higherorder

object FoldDemo {
  
  def add(acc:Int, value: Int):Int = 
    {
     println(s"acc= $acc , value = $value")
     acc + value
    }
  
  def main(args:Array[String]):Unit = {
    
    //Input List 1,2,3,4,5,6,7,8,9,10
    val nums = (1 to 10).toList
    
    //fold()()
    //0,1 = 1
    //1,2 = 3 
    //3,4 = 7
    val ouput:Int = nums.fold(5)(add(_,_))  
    //String interpolation
    println(s"Output = $ouput")
    
    
    
  }
}