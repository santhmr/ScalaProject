package com.scalatraining.functions.higherorder
//map (func) HOF
//map 1 to 1 transformation
//Int => Int

object MapDemo {
  
  //(Int) => (Int)
  def add10(i:Int):Int = i+10
  
  def main(args:Array[String]):Unit ={
    val nums : List[Int] = (1 to 10).toList
    nums.foreach(println)
    
    //1,2,3,4,5,6,7,8,9,10 => 11,12,13,14,15,16,17,18,19,20
   val add10List:List[Int] =  nums.map(add10(_))
   add10List.foreach(println)
    
    
  }
  
}