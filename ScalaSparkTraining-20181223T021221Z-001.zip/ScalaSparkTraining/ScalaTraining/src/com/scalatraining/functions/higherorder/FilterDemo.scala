package com.scalatraining.functions.higherorder

object FilterDemo {
  
  //(Int) => Boolean (true/false)
  def isEvenNum(n:Int):Boolean ={
    return n%2 == 0 
  }
  
  //(Int) => Unit 
  def printNum(i:Int):Unit = println(i)
  
  
  
  def main(args:Array[String]):Unit ={
    
    val nums:List[Int] = (1 to 10).toList
    
    //1. Traditional for loop
    for( i <- nums ){
      if(i%2 == 0)
        println(i)
    }
    
    // 2. 
    for( i <- nums if(i%2 == 0) ){
        println(i)
    }
    
    //functional style 
    //Higher Order function -- function will takes another function as a parameter
    // filter 
    // map
    // flatMap
    // reduce
    // foreach
    
    //2,4....10    
    val evenList:List[Int]= nums.filter(isEvenNum(_)) // func true collect,false not collect
    
    println("filter")
    for( e <- evenList)
      println(e)
    
    //HOF  
    evenList.foreach(printNum(_)) 
    evenList.foreach(println)
    
    
  }
}