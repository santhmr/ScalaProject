package com.scalatraining.functions.higherorder

//flatMap is HOF 
// 1 to many transformation
// map + flatten = flatMap 

object FlatMapDemo {
  
  
  def splitStr(s:String):Array[String] = {
    s.split(" ")
  }
  
  
  def main(args:Array[String]):Unit = {
    
    val strList = List(
           "Scala is a functional programming",
           "Scala is an object oriented programming",
           "Scala is run jvm"
        )
    
    /*// "Scala is a functional programming" => ["Scala","is","a","functional","programing"]  
    val splitStrList = strList.map(splitStr(_))
    splitStrList.foreach(println)
    
    //flatten
    val flattenWords = splitStrList.flatten
    flattenWords.foreach(println) */
    
    
   strList.flatMap(splitStr(_)).foreach(println)
    
  }
  
}