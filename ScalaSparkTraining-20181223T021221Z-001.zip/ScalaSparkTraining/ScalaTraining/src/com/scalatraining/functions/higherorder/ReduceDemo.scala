package com.scalatraining.functions.higherorder

object ReduceDemo {
  
  //(Int,Int) => Int 
  def add(i:Int, j:Int) : Int =
    {
     println(i +" "+ j)
      i+j
    }
 
  def main(args:Array[String]):Unit ={
    
    //Input (1,2,3,4,5,6,7,8,9,10) 
    val nums = (1 to 10).toList
    
    //HOF
    //add(1,2) = 3
    //add(3,3) = 6
    val sum = nums.reduce(add(_,_))
    println(sum)
    
  }
  
}