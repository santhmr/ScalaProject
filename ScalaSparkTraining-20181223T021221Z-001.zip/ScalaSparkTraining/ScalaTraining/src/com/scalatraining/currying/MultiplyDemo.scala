package com.scalatraining.currying

object MultiplyDemo {
  
  def mulitply(a:Int, b:Int) = a * b
  
  //Curry func-- multiple parameter list
  def multiply1(a:Int)(b:Int) = a * b
  
  def main(args:Array[String]):Unit = {
    println(mulitply(10,20))
    println(multiply1(10)(20))
 
    //Partially Applied Functions
    //fold(5)(_,_)
   
    //(Int) => (Int)
    val mul: (Int) => (Int) = multiply1(5)(_)
    
   println(mul(4))
  }
}