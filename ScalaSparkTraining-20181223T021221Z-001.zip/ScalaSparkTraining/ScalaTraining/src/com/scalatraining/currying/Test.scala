package com.scalatraining.currying

object Test {
  
   def multiply(a:Int,b:Int) =a * b
   def multipycurry(a:Int)(b:Int) = a * b
   
   def main(args:Array[String]):Unit ={
    
    val mul = multipycurry(5)(_)
    
    print(mul(6))
  }
}
