package com.scalatraining

object PatternMatchingDemo {
  
  def main(args:Array[String]):Unit ={
    
    //Scala pattern matching constanst/value, variable, expressin and object (case class)
    
    val i = 10 
    
    i match {
      case 10 => println("value="+10)
      case 20 => println("value="+20)
      case _ => println("Other")
    }
    
    
   i match {
     
     case a if(a == 10) => println("value="+10)
     case a if(a == 20) => println("value="+20)
     case _ => println("Other")
     
   }
    
  }
  
}