package com.scalatraining.caseclass

abstract class Notification

case class Email(sender:String, title:String, body:String) extends Notification
case class SMS(caller:String, msg:String) extends Notification
case class VideoCalling(caller:String, link:String) extends Notification

object PatternTest{
  
  def main(args:Array[String]):Unit = {
    
    val notification:Notification = Email("Ram", "Scala Traing", "Welcome to scala")
      
    notification match { 
      case Email(name,title,_) => println(s"You got an email from $name with title $title")
      case SMS(caller,msg) => println(s"You got sms from $caller with $msg ")
      case _ => println("No notifications")
    }
    
  }
  
  
}
