package com.scalatraining.caseclass

//apply -- Create an object
//unapply -- Extracting an object values
//Schema creation 
//val e1 = new Employee(,,) -- normal class
//val e1 = Employee(,,) -- case class
case class Employee(val eid:Int, val ename:String, val salary:Double) {
  
 //Employee -> (eid,ename,salary) 
 def unapply( e:Employee) : Option[(Int,String,Double)] ={
   Some(e.eid, e.ename,e.salary)
 }
  
}


object EmployeeCaseTest{
  
  def main(args:Array[String]):Unit ={
    
    val e1 = new Employee(1,"ram",100.00)
    println(e1.eid)
    
    //Without new keyword
    val e2 = Employee(2,"kumar",200.00) // Employee.apply factory method
    println(s"eid=${e2.eid} ename=${e2.ename}")
    
    //Internally calling an apply
    val e3 = Employee.apply(3, "krishna", 300.00)
    
    println(s"eid=${e3.eid} ename=${e3.ename}")
    
    val empTuple = Employee.unapply(e3)
    println(empTuple)
    
    //Tuple
    val t:(Int,String,Double) = empTuple.get
    
    println(t._1)
    println(t._2)
    println(t._3)
    
  }
  
}
