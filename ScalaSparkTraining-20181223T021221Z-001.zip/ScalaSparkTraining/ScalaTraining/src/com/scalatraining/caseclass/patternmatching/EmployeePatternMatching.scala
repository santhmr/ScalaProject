package com.scalatraining.caseclass.patternmatching

import com.scalatraining.caseclass.Employee

object EmployeePatternMatching {
  
  def main(args:Array[String]):Unit = {
    
    val e1 = Employee(2,"Ram",111.00)
    
    e1 match { 
      case Employee(1,"Ram",111.00) => println("This is ram")
      case _ => println("Other employee")
      
    }
    
    
   e1 match{
     
     case Employee(1,a,_) => println(s"Your employee id is : 1 ename : $a")
     case _ => println("other")
      
   }
    
    
    
    
    
  }
}