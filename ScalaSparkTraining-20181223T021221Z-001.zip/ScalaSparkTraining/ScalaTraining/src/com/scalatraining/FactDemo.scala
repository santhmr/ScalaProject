package com.scalatraining

import scala.io.StdIn

object FactDemo {
  
  def main(args:Array[String]):Unit ={
    
    val inputValue = StdIn.readInt()
    val temp = inputValue
    var n = inputValue
    var fact =1 
    
    
    while(n >= 1){
      println(n)
      fact = fact * n
      n=n-1
    }
    println(s"Factorial of $temp = $fact")
    
  }
}