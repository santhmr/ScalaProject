package com.scalatraining.exceptionhandling

object ExceptionDemo1
{

  def main(args: Array[String]): Unit =
  {
    try
      {
        //Arithmetic Exception
        val result= 10/1
        println(result)

        //ArrayIndexOutOfBoundException
        val arr = Array(1,2)
        println(arr(4))

        //NumberFormatException
        val s:String= "100"
        println(s.toInt)

        //Nullpointer Exception
        val s1:String = "AVC"
        if(s1 !=null)
            println(s1.length)
        else
          println("s1 is null")
      }
      catch{
          case ae:ArithmeticException => println(ae)
          case aiobe: ArrayIndexOutOfBoundsException => println(aiobe)
          case nfe : NumberFormatException => println("Please enter  valid input string")
          case other:Exception => println(other)
        }
        finally
        {
          println("close or clean any objects.....")
        }

    println("Remaining statements")

  }

}
