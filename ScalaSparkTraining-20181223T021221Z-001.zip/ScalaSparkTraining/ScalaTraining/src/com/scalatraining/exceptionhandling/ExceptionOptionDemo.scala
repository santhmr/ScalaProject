package com.scalatraining.exceptionhandling

object ExceptionOptionDemo
{
  /*
      colorCode returns matching num
      Params :    colorInput:String
      Return : Option[Int]
   */

  def colorCode (colorInput:String) : Option[Int] = {

    val result = colorInput match {

      case "RED" => Some(1)  // Some value 1  Some wrapper object which will hold value
      case "BLUE" => Some(2)
      case "GREEN" => Some(3)
      case _ => None   // no value
    }

    result
  }


  def main(args: Array[String]): Unit =
  {
    val colorCode1 =  colorCode("RED")  // Some(1) None


    colorCode1 match
      {
      case  Some(num) => println("Color code of red ="+num)
      case None => println("color code of orange is not defined")
    }



  }



}
