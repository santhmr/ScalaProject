package com.scalatraining.exceptionhandling

import scala.util.{Failure, Success, Try}


object TryDemo
{
  def main(args: Array[String]): Unit = {

    val result:Try[Int] = convertStringToInt("100")
    
    //1
  /*  result match {

      case Success(res) => println(res)
      case Failure(ex) => println("Exception occurred"+ex)

    }*/
    
    
    //2
    result.map {
      case num => println(num)
    } recover{
      case ex:Exception => println(ex)
    }
  }


  def convertStringToInt(s:String) : Try[Int] = {

    Try
    {
      s.toInt  //Success(100) or Failure()
    }
  }


}
