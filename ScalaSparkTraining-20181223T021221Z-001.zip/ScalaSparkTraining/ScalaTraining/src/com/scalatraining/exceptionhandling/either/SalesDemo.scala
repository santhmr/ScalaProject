package com.scalatraining.exceptionhandling.either

import scala.io.StdIn

case class SalesRecord(val transactionId:String,val customerId:String,val itemId:String,val amount:Double)

//Either[Left,Right] , Left , Right 
object SalesDemo
{

  def parse(str:String) : Either[SalesRecordException,SalesRecord]={
    //"111,c1,i1,10000.00"
    val colums:Array[String] = str.split(",")

    if(colums.length<4)
      {
       Left(new SalesRecordException)
      }
     else
      {
        val tId = colums(0)
        val cId = colums(1)
        val iId = colums(2)
        val amount = colums(3).toDouble
        Right(SalesRecord(tId,cId,iId,amount))
      }

  }


  def main(args: Array[String]): Unit =
  {
    println("Please enter sales input string")
    val salesStr :String = StdIn.readLine()

    val either = parse(salesStr)

    println(either)

    if(either.isLeft)
      {
        println("Fault Record")
      }
      else
      {
        println("Proper Record")
        println(either.right.get)

      }
  }

}
