package com.scalatraining.exceptionhandling.either

class SalesRecordException extends Exception
