package com.scalatraining.exceptionhandling

/**
  *  throw  -- used thrown an exception object (ArithmeticException, SalesRecordException)
  *  throws  -- @throws
  */
object ExceptionThrowsDemo
{
  /*
    throws -- method level
    throws used forward or propagate an exception to caller (m1)
   */
  @throws(classOf[ArithmeticException]) //ArithmeticException.class
  @throws(classOf[Exception])
  def m1:Unit  = {
    println("m1 func is called...")

        val result = 10/0 // internally throw an ArithmeticException
        //throw new ArithmeticException()
        println(result)

  }
  @throws(classOf[ArrayIndexOutOfBoundsException])
  def m2:Unit =
  {
    val arr = Array(1,2)
    //println(arr(2)) 
    throw new ArrayIndexOutOfBoundsException
  }
  //caller
  def main(args:Array[String]):Unit =
  {
    try
      {
         m1 //calling m1
         m2  //calling m2
      }
      catch
       {
          case e:ArithmeticException => println(e)
          case e1:ArrayIndexOutOfBoundsException =>println(e1)
       }

  }




}
