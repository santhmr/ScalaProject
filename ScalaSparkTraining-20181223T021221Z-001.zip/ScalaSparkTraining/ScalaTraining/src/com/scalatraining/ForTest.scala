package com.scalatraining

object ForTest {
  
  def main(args:Array[String]):Unit ={
    
    //Input
    val nums:Array[Int] = Array(1,2,3,4,5)
    
    //for 
    for(e <- nums if(e%2==0) )
      println(e)
      
    val evenNums:Array[Int] = for( e <- nums if(e%2==0)) yield e
    
    for(e <- evenNums)
       println(e)
    
    println("functional") 
    nums.foreach(println)   
    
  }
  
}