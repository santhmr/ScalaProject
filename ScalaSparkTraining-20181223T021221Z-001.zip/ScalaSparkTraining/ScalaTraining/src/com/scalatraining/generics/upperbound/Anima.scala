package com.scalatraining.generics.upperbound

class Animal
{
  def name = "animal"
}

class Lion extends Animal
{
  override def name = "Lion"
}

class Pet extends Animal
{
  override def name = "Pet"
}
class Cat extends Pet
{
  override def name = "Cat"
}
class Dog extends Pet
{
  override  def name = "dog"
}
//Upper bounds  Same type and thier subtypes 
//Pet , Dog and Cat 
class Cage[P<:Pet](p:P)
{

  def pet: P = p

}

object Cage
{
  def main(args: Array[String]): Unit = {

    val a = new Animal
    val l = new Lion
    val p = new Pet
    val d = new Dog
    val c = new Cat

   /* val aCage = new Cage[Animal](a)
    println(aCage.pet.name)*/
    
    //val lCage = new Cage[Lion](l)
    val pCage = new Cage[Pet](p)
    println(pCage.pet.name)

    val dCage = new Cage[Dog](d)
    println(dCage.pet.name)

    val cCage = new Cage[Cat](c)
    println(cCage.pet.name)

  }

}



