package com.scalatraining.generics

/**
  *  Subtyping of generic types is *invariant*. for example 'a' is subtype of Int
  *  Here T is a Type Parameter ans S is a type. By declaring Upper Bound like “[T <: S]” means this Type Parameter T must be either same as S or Sub-Type of S.
  */
class Stack[T]
{

var elems:List[T] = Nil

def push(x:T) =
{
  elems = x :: elems
}

 def top = elems.head

  def pop =
  {
    elems = elems.tail
  }

}

object Stack extends App
{
  val s1 = new Stack[Int]
  val s2 = new Stack[Long]

  val short:Short = 10
  s1.push(1)
  s1.push(2)
  s1.push(3)
  s1.push('a') //Char 2 byte 
  s1.push(short)

  //s1.pop
  println(s1.elems.size)

  println(s1.top)

  println(s1.elems)

}
