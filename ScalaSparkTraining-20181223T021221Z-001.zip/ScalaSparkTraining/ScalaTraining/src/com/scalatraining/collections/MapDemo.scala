package com.scalatraining.collections

/**
  * Created by admin1 on 2/7/2017.
  */
object MapDemo
{
  def main(args: Array[String]): Unit =
  {
    // Map is Collection of (K,V) pair -- Example  (ename,"prakash")
    //Map[KT,VT]  --Map[String,Int]
    //Keys are unique
    //Values are duplicate

    val map = Map(("One",1),("Two",2),("Three",3),("Four",4))
    println(map)

    val map1 = Map("One"->1,"Two"->2,"Three"->3,"Four" -> 4) // toString representation
    println(map1)

    //Values
   val mapValues:Iterable[Int] =  map1.values

    mapValues.foreach(println)

    println("Iterator")

    val itr = mapValues.iterator
    while(itr.hasNext)
      {
        println(itr.next)
      }


    println("Keys..")
    val keys = map1.keys
    println("foreach..")
    keys.foreach( key => {
      val v= map1.get(key)
      println(key + "\t" + v.get)
    })

    println("iterator")

    val itr2 = keys.iterator
    while(itr2.hasNext)
    {
      val key = itr2.next
      val value = map1.get(key)

      println(key + "\t"+value)
    }

    
   val map2 = map + ("Four" -> 4)
    println(map2)

    println(map2.contains("Five"))

    println(map2.get("Five")) // Option[Int] Some(1) or None 
    //Some, None Option
    println(map2.getOrElse("Five","Not Found"))
    println(map2.get("Four").getOrElse("Not Found"))


  }

}
