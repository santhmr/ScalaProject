package com.scalatraining.collections


object ListDemo
{

  def main(args: Array[String]): Unit =
  {
   /*
      List -- Collection of elements(values) with duplicates
      List -- linear access
     Generic Type
     List[T] -- Type
     T- Int
     T- Short
     T- Empoyee
     T-Customer

     Immutable
     */

    val numsList:List[Int] = List(1,2,3,4,5,5,6)
    println(numsList) //prints list values in string

    //Add Opertions
    val numsList1 = numsList :+ 7
    println(numsList1)

    //Prepand operation append element at head / tail
    val numList99 = 99 :: numsList

    println(numList99)

    println("for loop")
    for(num<-numList99)
      println(num)

    println("foreach")
    numList99.foreach((e:Int) => println(e))

    println("Iterator Create -- Traversing an elem in collection")
    val itr:Iterator[Int] = numList99.iterator
    while(itr.hasNext) //is element
      {
        println(itr.next) //get an element
      }

    println(numList99.isEmpty)
    println(s"head= ${numList99.head}")  // first
    println(s"tail= ${numsList.tail}")

    //Aggregation function
   val sum = numList99.sum
    println("SUM="+sum)

    val min = numList99.min
    println("MIN="+min)

    val max = numList99.max
    println("MAX="+max)

  }

}
