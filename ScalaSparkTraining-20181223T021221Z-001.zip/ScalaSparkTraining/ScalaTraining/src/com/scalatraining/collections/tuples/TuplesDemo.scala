package com.scalatraining.collections.tuples


object TuplesDemo
{
  def main(args: Array[String]): Unit =
  {
    //Int,String,Salary
    // (01,"Ram","ram@gmail.com",1111.00)

    val employee : (Int,String,Double) = (1,"Prakash",20000.00)

    val eid = employee._1
    val ename = employee._2
    val salary = employee._3

    println(eid)
    println(ename)
    println(salary)


    //List of employees  (eid,ename,salary)
     val empList :List[(Int,String,Double)] = List((1,"A",100.00),(2,"B",200.00),(3,"C",300.00))

    empList.foreach(emp => println(emp._2 +"\t"+emp._3))


  }

}
