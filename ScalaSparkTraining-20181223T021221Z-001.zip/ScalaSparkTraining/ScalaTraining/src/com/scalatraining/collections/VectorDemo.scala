package com.scalatraining.collections

object VectorDemo
{

  def main(args: Array[String]): Unit =
  {
    /*
       Vector -- Collection of elements(values) with duplicates
       Vector -- Random access
       Vector -- 32 *32
      Generic Type
      Vector[T] -- Type
      T- Int
      T- Short
      T- Empoyee
      T-Customer
      */

    val numsList:Vector[Int] = Vector(1,2,3,4,5,5,6)
    println(numsList) //prints list values in string

    //Add Opertions
    val numsList1 = numsList :+ 6
    println(numsList1)


    println(numsList1)

    println("for loop")
    for(num<-numsList1)
      println(num)

    println("foreach")
    numsList1.foreach(println)

    println("Iterator Create -- Traversing an elem in collection")
    val itr:Iterator[Int] = numsList1.iterator
    while(itr.hasNext) //is element
    {
      println(itr.next) //get an element
    }

    println(numsList1.isEmpty)
    println(numsList1.head)  // first
    println(numsList.tail)

    //Aggregation function
    val sum = numsList1.sum
    println("SUM="+sum)

    val min = numsList1.min
    println("MIN="+min)

    val max = numsList1.max
    println("MAX="+max)

  }

}
