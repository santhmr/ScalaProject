package com.scalatraining.collections.mutable

import scala.collection.mutable.HashMap
object Map {

  def main(args: Array[String]): Unit = {

  //(K,V),(K,V) k->V, 
  val map = new HashMap[Int,String]()
  map += (1 -> "make a web site")
  map += (3 -> "profit!")
  map += (5 -> "Spark")

    //getValue by key
  println(map(1))
  println(map.get(1))
  
  println(map.contains(2))
  println(map contains 1 ) //English like syntax
  println(map)
  println(map.isEmpty)

  //  mutable map to immutable
   val imMap = map.toMap
   val imMap1 = imMap + (4 -> "Scala")

    println(imMap)
    println("imMap1"+imMap1)



    println("Values only")

   val col =  map.values

    val itr = col.iterator

    while(itr.hasNext)
      println(itr.next())


      println("Keys only")

    val keys= map.keySet

    val itr1 = keys.iterator

    while(itr1.hasNext)
      {
        val key = itr1.next()
        val value = map(key)
        println(key +"\t"+value)

      }


    for( key <-keys)
      println(key)
    
  }

}