package com.scalatraining.collections.mutable

import scala.collection.mutable.Stack

object StacksDemo {

  def main(args: Array[String]): Unit = 
  {
     //LIFO
     val stack = new Stack[Int]
     stack.push(1)
     stack.push(2)
     stack.push(3)
     stack.push(4)
     stack.push(5)
     println(stack)
     
     println(stack.top) // get the last element 5
     println(stack.pop) // get & remove last element 5
     
     println(stack)
    
  }

}