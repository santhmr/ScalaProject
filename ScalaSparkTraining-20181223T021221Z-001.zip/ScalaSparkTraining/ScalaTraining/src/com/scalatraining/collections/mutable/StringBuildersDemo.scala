package com.scalatraining.collections.mutable

object StringBuildersDemo {

  def main(args: Array[String]): Unit = {
    val buf = new StringBuilder
    buf += 'a'
    buf ++= "bcdef"

    buf.update(0,'X')
    buf.delete(0,1)


    //mutatble to immutable
    val s:String = buf.toString

    val uc = s.toUpperCase

    val s1 = s.substring(2)

    val s2 = s1+ "XYZ"

    println(s1)
    println(buf.toString)

    println(uc)
   
  }

}