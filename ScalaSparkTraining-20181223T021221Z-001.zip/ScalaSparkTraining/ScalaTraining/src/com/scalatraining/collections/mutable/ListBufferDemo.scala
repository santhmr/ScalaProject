package com.scalatraining.collections.mutable

import scala.collection.mutable.ListBuffer

object ListBufferDemo extends App {

  val listBuf = new ListBuffer[String]()

  println(listBuf.isEmpty)
  listBuf += "Prakash"
  listBuf += "Chenga"
  println(listBuf.isEmpty)
  println(listBuf.size)
  listBuf += "Scala"
  listBuf += "Collection"

  println(listBuf.size)

  //mutable list buf to list
  println(listBuf.toList) 
  
  listBuf.foreach(element => println(element))
  listBuf foreach println
}