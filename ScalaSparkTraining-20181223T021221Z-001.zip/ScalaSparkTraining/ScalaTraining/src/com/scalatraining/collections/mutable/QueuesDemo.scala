package com.scalatraining.collections.mutable

import scala.collection.mutable.Queue

object QueuesDemo {

  def main(args: Array[String]): Unit = {
    //FIFO
    val queue = new Queue[String]
    queue += "a" //queue = queue + "a"
    queue ++= List("b", "c")
    queue += "d"
    queue ++= List("e", "f","g","h")
    
    println(queue)   //a,b,c,d,e,f,g,h
    queue.dequeue //a removed b,c,d,e,f,g,h
    queue.dequeue //b removed c,d,e,f,g,h
    println(queue) //c,d,e,f,g,h
    
  }

}