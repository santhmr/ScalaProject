package com.scalatraining.collections


object SetDemo
{
  def main(args: Array[String]): Unit = {
    //Set -- Collection of elements(values) without duplicates

    val numsList = Set(1,1,2,3,4,5,6,6)
    println(numsList)

    val numsList1 :Set[Int] = numsList +7
    println(numsList1)
    println(numsList1.isEmpty) //??
    println(numsList1.head)
    println(numsList1.tail)

    println("for loop")
    for(num<-numsList1)
      println(num)

    println("foreach")
    numsList1.foreach(println)

    println("Iterator Create -- Traversing an elem in collection")
    val itr:Iterator[Int] = numsList1.iterator
    while(itr.hasNext) //is element
    {
      println(itr.next) //get an element
    }




  }

}
