package com.scalatraining.collections


object ParallelCollection
{
  def main(args: Array[String]): Unit = {

    val startTime = System.currentTimeMillis()
    
    val list = (1 to 100000).toList
    println(list.par.sum)
    val endTime = System.currentTimeMillis()

    val timeTaken = endTime-startTime

    println (s"Start Time = $startTime End Time = $endTime Time Taken = $timeTaken")
  }

}
