package com.scalatraining.oop.abstractclasses

//Can't create an object
//Should be sub class
abstract class Animal() {
  
  //Constructor
  def this(name:String){
    this()
  }
  
  //Abstract methods 
  def eating:Unit
  def sounds:Unit
  
  //Concrete
  def running:Unit ={
    println("Animal is running")
  }
  
  
}

class Dog extends Animal{
  
  def eating:Unit ={
    println("Dog is eating ....")
  }
  
  def sounds:Unit = println("Dog souds like bow bow..")
  
  
override def running:Unit = {
     println("Dog is barking & running")
  }
  
}


class Cat extends Animal{
  
  def eating:Unit ={
    println("Cat is drinking milk ....")
  }
  
  def sounds:Unit = println("Cat souds like meow meow..")
  
  
override def running:Unit = {
     println("Cat is running")
  }
  
}


object Test{
  
  def main(args:Array[String]):Unit ={
    
    //val a:Animal = new Animal
    
    val d = new Dog
    d.eating
    d.sounds
    d.running
    
    val c = new Cat
    c.eating
    c.sounds
    c.running
    
    //Dynamic Dispatch
    val animal:Animal = new Dog
    animal.eating
    animal.running
    animal.sounds
    
    //Dynamic Dispatch
    val animal1:Animal = new Cat
    animal1.eating
    animal1.running
    animal1.sounds
    
    
    
  }
  
}