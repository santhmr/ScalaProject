package com.scalatraining.oop

//Primary constructor
class Employee(val eid:Int, var  ename:String, val email:String, val salary:Double){
  
  //Secondary Constructors
  def this(eid:Int){
    this(eid,null,null,0.0) //calling primary constructor
    println("1 arg constructor")
  }
  
  def this(eid:Int,ename:String){
    this(eid,ename,null,0.0)
    println("2 arg constructor")
  }
  
  def this(){
    this(0,null,null,0.0) //primary constructor
    println("0 arg constructor")
  }
 
  //Business logic method
  def displayEmployee(){
    println(s"eid=$eid ename=${ename} email=$email salary=$salary")    
  }
 
  
}

object EmployeeTest{
  
  def main(args:Array[String]):Unit ={
     
     val e1:Employee = new Employee() // this()
     e1.displayEmployee()
     
     val e2 = new Employee(1,"Ram","ram@gmail.com",99999.99)
     e2.displayEmployee()
     
     val e3 = new Employee(1)
     e3.displayEmployee()
    
  }
  
}
