package com.scalatraining.oop.traits

//Can't create an object 
//Can't write constructor
//purely abstract or 100%
trait Animal {
 
  //Abstract methods 
  def eating:Unit
  def sounds:Unit
  
  //Default 
  def running:Unit ={
    println("Animal is running")
  }
  
}

trait T1 {
  def m1:Unit
}
trait T2  {
  def m1:Unit
}


class Cat extends Animal with T1 with T2{
  
  def m1:Unit = println("T1 m1")
  
  
  def eating:Unit ={
    println("Cat is drinking milk ....")
  }
  
  def sounds:Unit = println("Cat souds like meow meow..")
  
  
override def running:Unit = {
     println("Cat is running")
  }
  
}

class Dog extends Animal{
  
  def eating:Unit ={
    println("Dog is eating ....")
  }
  
  def sounds:Unit = println("Dog souds like bow bow..")
  
  
override def running:Unit = {
     println("Dog is barking & running")
  }
  
}

object Test{
  
  def main(args:Array[String]):Unit ={
    
    //val a:Animal = new Animal
    
    val d = new Dog
    d.eating
    d.sounds
    d.running
    
    val c = new Cat
    c.eating
    c.sounds
    c.running
    c.m1
    
    //Dynamic Dispatch
    val animal:Animal = new Dog
    animal.eating
    animal.running
    animal.sounds
    
    //Dynamic Dispatch
    val animal1:Animal = new Cat
    animal1.eating
    animal1.running
    animal1.sounds
    
    
    
  }
  
}