package com.scalatraining

import scala.annotation.tailrec

object FactTailRec {
  
  //1*5 = 5 
  //5*4 = 20
  //20*3 = 60
  //60*2 = 120
  //120*1 =120
  //120
   @tailrec 
   def fact(acc:Int, n:Int):Int = {
     println(s"acc=$acc, n=$n")
 
    if(n==0)
      acc
    else{
      fact(n*acc, n-1)  
    }
     
   /*val res=  n match{
      case n if(n==0) => acc
      case _  => fact(n*acc, n-1) 
    }
   println(s"After fact acc= $acc n=$n")
   res */
  }
   
   def main(args:Array[String]):Unit = {
     
     println(fact(1, 5))
     
   }
  
}