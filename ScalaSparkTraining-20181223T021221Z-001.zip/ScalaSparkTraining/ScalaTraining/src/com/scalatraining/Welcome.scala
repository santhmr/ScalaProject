package com.scalatraining

object Welcome {
  
  def main(args:Array[String]):Unit ={
    println("Welcome to Scala")
  }
}