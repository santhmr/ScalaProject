//Singleton- single object for this class 
object Welcome{

def main(args:Array[String]):Unit = {
	println("Good Morning All!, Welcome to scala..")
}


}